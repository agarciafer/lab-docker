# docker-simplest-nodeapp
Docker Simplest Nodeapp - Show IP and SERVER HOSTNAME

It will run a small nodejs app on port 3000

docker run -d  --hostname=simplest-nodeapp -P simplest-nodeapp


