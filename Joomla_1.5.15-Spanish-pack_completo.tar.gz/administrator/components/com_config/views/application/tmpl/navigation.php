<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>
<div class="submenu-box">
	<div class="submenu-pad">
		<ul id="submenu" class="configuration">
			<li><a id="site" class="active"><?php echo JText::_( 'Site' ); ?></a></li>
			<li><a id="system"><?php echo JText::_( 'System' ); ?></a></li>
			<li><a id="server"><?php echo JText::_( 'Server' ); ?></a></li>
		</ul>
		<div class="clr"></div>
	</div>
</div>
<div class="clr"></div>
